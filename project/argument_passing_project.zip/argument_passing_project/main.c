#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

volatile sig_atomic_t signal_received = 0;

void signal_handler(int sig)
{
    signal_received = sig;
}

void print_arguments(int argc, char *argv[])
{
    printf("\nArguments received from shell:\n");

    for (int i = 0; i < argc; i++)
    {
        printf("argv[%d] = %s\n", i, argv[i]);
    }
}

void execute_command(int argc, char *argv[])
{
    printf("\n===============================================\n");
    printf("        ARGUMENT PASSING / COMMAND EXECUTION\n");
    printf("===============================================\n");

    printf("\n[CO-1] Shell → Argument Passing\n");
    printf("Parent PID : %d\n", getpid());
    printf("Command    : %s\n", argv[1]);

    print_arguments(argc, argv);

    printf("\n[CO-2] Process Creation\n");
    printf("-----------------------------------------------\n");

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        printf("\n[CHILD]\n");
        printf("Child PID  : %d\n", getpid());
        printf("Parent PID : %d\n", getppid());

        printf("\nArguments passed to child:\n");

        for (int i = 1; i < argc; i++)
        {
            printf("argv[%d] = %s\n", i, argv[i]);
        }

        printf("\nExecuting using execvp()...\n");
        printf("-----------------------------------------------\n");

        execvp(argv[1], &argv[1]);

        perror("execvp");
        exit(EXIT_FAILURE);
    }

    int status;

    printf("\n[PARENT]\n");
    printf("Child PID : %d\n", pid);
    printf("Waiting using waitpid()...\n");

    waitpid(pid, &status, 0);

    printf("\nChild execution finished.\n");

    if (WIFEXITED(status))
    {
        printf("Exit Status : %d\n", WEXITSTATUS(status));
    }

    printf("===============================================\n");
}

void pipe_demo(const char *message)
{
    int fd[2];

    printf("\n===============================================\n");
    printf("              CO-3 IPC: PIPE\n");
    printf("===============================================\n");

    if (pipe(fd) == -1)
    {
        perror("pipe");
        return;
    }

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        close(fd[1]);

        char buffer[1024];

        ssize_t bytes = read(fd[0], buffer, sizeof(buffer) - 1);

        if (bytes > 0)
        {
            buffer[bytes] = '\0';

            printf("\n[CHILD]\n");
            printf("PID : %d\n", getpid());
            printf("Data received through pipe:\n");
            printf("%s\n", buffer);
        }

        close(fd[0]);
        exit(0);
    }

    close(fd[0]);

    printf("\n[PARENT]\n");
    printf("PID : %d\n", getpid());
    printf("Sending data through pipe:\n");
    printf("%s\n", message);

    write(fd[1], message, strlen(message));

    close(fd[1]);

    waitpid(pid, NULL, 0);

    printf("\nIPC communication completed.\n");
    printf("===============================================\n");
}

void signal_demo()
{
    printf("\n===============================================\n");
    printf("             CO-3 SIGNAL CONTROL\n");
    printf("===============================================\n");

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        signal(SIGUSR1, signal_handler);

        printf("\n[CHILD]\n");
        printf("PID : %d\n", getpid());
        printf("Waiting for SIGUSR1...\n");

        while (!signal_received)
        {
            pause();
        }

        printf("\nSIGUSR1 received.\n");
        printf("Signal handler executed.\n");

        exit(0);
    }

    sleep(1);

    printf("\n[PARENT]\n");
    printf("PID       : %d\n", getpid());
    printf("Child PID : %d\n", pid);

    printf("Sending SIGUSR1...\n");

    kill(pid, SIGUSR1);

    waitpid(pid, NULL, 0);

    printf("\nSignal communication completed.\n");
    printf("===============================================\n");
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("\nLINUX ARGUMENT PASSING SYSTEM\n\n");

        printf("Usage:\n");
        printf("  %s <command> [arguments...]\n", argv[0]);
        printf("  %s --pipe <message>\n", argv[0]);
        printf("  %s --signal\n\n", argv[0]);

        printf("Examples:\n");
        printf("  %s echo Hello Ubuntu\n", argv[0]);
        printf("  %s ls -l\n", argv[0]);
        printf("  %s pwd\n", argv[0]);
        printf("  %s --pipe \"Hello Child\"\n", argv[0]);
        printf("  %s --signal\n", argv[0]);

        return 1;
    }

    if (strcmp(argv[1], "--pipe") == 0)
    {
        if (argc < 3)
        {
            printf("Usage: %s --pipe <message>\n", argv[0]);
            return 1;
        }

        pipe_demo(argv[2]);
        return 0;
    }

    if (strcmp(argv[1], "--signal") == 0)
    {
        signal_demo();
        return 0;
    }

    execute_command(argc, argv);

    return 0;
}
