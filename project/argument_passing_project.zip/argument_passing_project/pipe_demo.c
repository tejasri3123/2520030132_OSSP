#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>

void pipe_demo()
{
    int fd[2];

    printf("\n===========================================\n");
    printf("       ANONYMOUS PIPE DEMONSTRATION\n");
    printf("===========================================\n");

    if (pipe(fd) == -1)
    {
        perror("pipe");
        return;
    }

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        close(fd[1]);

        char message[256];

        printf("[Child] Waiting for data from parent...\n");

        ssize_t n = read(fd[0], message, sizeof(message) - 1);

        if (n > 0)
        {
            message[n] = '\0';

            printf("[Child] Received through pipe:\n");
            printf("        %s\n", message);
        }

        close(fd[0]);

        printf("[Child] Pipe communication completed.\n");

        exit(0);
    }
    else
    {
        close(fd[0]);

        char message[256];

        printf("[Parent] Enter message for child: ");
        fflush(stdout);

        if (fgets(message, sizeof(message), stdin) != NULL)
        {
            message[strcspn(message, "\n")] = '\0';

            write(fd[1], message, strlen(message));
        }

        close(fd[1]);

        waitpid(pid, NULL, 0);

        printf("[Parent] Child completed communication.\n");
    }

    printf("===========================================\n");
}
