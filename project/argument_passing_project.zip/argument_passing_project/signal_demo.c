#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>

volatile sig_atomic_t signal_received = 0;

void handle_signal(int sig)
{
    signal_received = sig;
}

void signal_demo()
{
    printf("\n===========================================\n");
    printf("          SIGNAL DEMONSTRATION\n");
    printf("===========================================\n");

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        signal(SIGUSR1, handle_signal);

        printf("[Child] Child PID: %d\n", getpid());
        printf("[Child] Waiting for SIGUSR1...\n");

        while (!signal_received)
        {
            pause();
        }

        printf("[Child] SIGUSR1 received!\n");
        printf("[Child] Signal handler executed successfully.\n");
        printf("[Child] Terminating...\n");

        exit(0);
    }
    else
    {
        sleep(2);

        printf("[Parent] Parent PID: %d\n", getpid());
        printf("[Parent] Sending SIGUSR1 to child %d...\n", pid);

        kill(pid, SIGUSR1);

        waitpid(pid, NULL, 0);

        printf("[Parent] Child completed signal handling.\n");
    }

    printf("===========================================\n");
}
