#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

void process_demo()
{
    printf("\n===========================================\n");
    printf("       PROCESS CREATION DEMONSTRATION\n");
    printf("===========================================\n");

    printf("[Parent] Current PID: %d\n", getpid());
    printf("[Parent] Creating child using fork()...\n");

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        printf("\n[Child]\n");
        printf("Child PID       : %d\n", getpid());
        printf("Parent PID      : %d\n", getppid());
        printf("Process created successfully.\n");

        printf("\n[Child] Performing child task...\n");

        sleep(2);

        printf("[Child] Task completed.\n");
        printf("[Child] Terminating...\n");

        exit(0);
    }
    else
    {
        int status;

        printf("\n[Parent]\n");
        printf("Parent PID      : %d\n", getpid());
        printf("Child PID       : %d\n", pid);

        printf("[Parent] Waiting for child...\n");

        waitpid(pid, &status, 0);

        if (WIFEXITED(status))
        {
            printf("[Parent] Child exited normally.\n");
            printf("[Parent] Exit status: %d\n",
                   WEXITSTATUS(status));
        }
    }

    printf("===========================================\n");
}
