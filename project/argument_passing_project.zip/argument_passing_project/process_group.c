#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

void process_group_demo()
{
    printf("\n===========================================\n");
    printf("       PROCESS GROUP DEMONSTRATION\n");
    printf("===========================================\n");

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return;
    }

    if (pid == 0)
    {
        setpgid(0, 0);

        printf("[Child] PID              : %d\n", getpid());
        printf("[Child] Parent PID       : %d\n", getppid());
        printf("[Child] Process Group ID : %d\n", getpgrp());

        printf("[Child] Working...\n");

        sleep(3);

        printf("[Child] Completed.\n");

        exit(0);
    }
    else
    {
        sleep(1);

        printf("[Parent] PID      : %d\n", getpid());
        printf("[Parent] Child PID : %d\n", pid);

        printf("[Parent] Waiting for child...\n");

        waitpid(pid, NULL, 0);

        printf("[Parent] Child process completed.\n");
    }

    printf("===========================================\n");
}
